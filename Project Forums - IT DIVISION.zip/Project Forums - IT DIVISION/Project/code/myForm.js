var form = document.getElementById('myForm');

form.onsubmit = function() {
    var nama = document.getElementById('nama');
    var umur = document.getElementById('umur');
    var email = document.getElementById('email');
    var genderMale = document.getElementById('male');
    var genderFemale = document.getElementById('female');
    var city = document.getElementById('city');
    var address = document.getElementById('address');

    if(nama.value(length) < 3) {
        alert("Nama minimal 3 karakter");
        return false;
    }
    
    else if(email.value.indexOf('@') == -1 || email.value.indexOf('.com') == -1) {
        alert('Email harus diisi dengan format email');
        return false;
    }

    else if(phone.value.indexOf(' ') == -1) {
        alert('Phone harus sesuai format');
        return false;
    }

    else if(genderMale.checked == false && genderFemale.checked == false){
        alert('Gender harus dipilih');
        return false;
    }
    
    else if(address.value.indexOf(' ') == -1) {
        alert('Alamat harus diisi');
        return false;
    }


    
    else {
        alert('Berhasil');
        return true;
    }
}